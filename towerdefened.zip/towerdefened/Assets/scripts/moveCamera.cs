﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moveCamera : MonoBehaviour {
	public float speed;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		float horizontal = Input.GetAxis ("Horizontal");
		float vertical = Input.GetAxis ("Vertical");
		transform.Translate (new Vector3(horizontal*-1f*speed*Time.deltaTime,0.0f,vertical*-1f*speed*Time.deltaTime),Space.World);
	}
	 
}
